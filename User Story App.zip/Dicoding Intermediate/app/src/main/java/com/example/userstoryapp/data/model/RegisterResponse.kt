package com.example.userstoryapp.data.model

data class RegisterResponse(
    val error: Boolean,
    val message: String
)