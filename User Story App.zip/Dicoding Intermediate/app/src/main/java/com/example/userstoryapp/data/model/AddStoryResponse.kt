package com.example.userstoryapp.data.model

data class AddStoryResponse(
    val error: Boolean,
    val message: String
)